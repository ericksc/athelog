-- MySQL dump 10.16  Distrib 10.1.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.20-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies` (
  `RowID` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(11) NOT NULL,
  `Email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `CompanyID` (`CompanyID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

/*!40000 ALTER TABLE `Companies` DISABLE KEYS */;
INSERT INTO `Companies` VALUES (1,'OdiseaSA',99999999,'odisea@odisea.co.cr','San Jose, 150001'),(2,'SerranoSA',555555555,'serrano@serrano.co.c','Heredia, Cariari'),(3,'CarguilLTDA',66666666,'carguil@carguil.sa.c','Cartago, Mercado'),(4,'CargoSHIP',22534504,'info@cargo.ship.cr','Parque Industrial C. Blancos '),(5,'FireINC',11111111,'info@fire.ucs.cal','Parque Industrial C. Blancos ');
/*!40000 ALTER TABLE `Companies` ENABLE KEYS */;

--
-- Table structure for table `Evaluations`
--

DROP TABLE IF EXISTS `Evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Evaluations` (
  `RowID` int(11) NOT NULL AUTO_INCREMENT,
  `PatientID` text COLLATE utf8_unicode_ci NOT NULL,
  `APP_Hypertension` text COLLATE utf8_unicode_ci NOT NULL,
  `APP_Diabetes` text COLLATE utf8_unicode_ci NOT NULL,
  `APP_Cardiomyopathy` text COLLATE utf8_unicode_ci NOT NULL,
  `APP_Obesity` text COLLATE utf8_unicode_ci NOT NULL,
  `APNP_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `AQX_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `MED_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `INJ_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `BodyComp_Weight` float NOT NULL,
  `BodyComp_FatMass` float NOT NULL,
  `BodyComp_MuscleMass` float NOT NULL,
  `BodyComp_BMI` float NOT NULL,
  `BodyComp_FatPer` float NOT NULL,
  `BodyComp_InBodyScore` float NOT NULL,
  `BodyComp_BasMet` float NOT NULL,
  `BodyComp_ViscFat` float NOT NULL,
  `BodyComp_Flex` float(10,0) NOT NULL,
  `BodyComp_MR` float NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `RowID` (`RowID`),
  UNIQUE KEY `RowID_2` (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Evaluations`
--

/*!40000 ALTER TABLE `Evaluations` DISABLE KEYS */;
/*!40000 ALTER TABLE `Evaluations` ENABLE KEYS */;

--
-- Table structure for table `Patients`
--

DROP TABLE IF EXISTS `Patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Patients` (
  `Row_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PatientID` int(11) NOT NULL,
  `Forename` text COLLATE utf8_unicode_ci NOT NULL,
  `FirstSurname` text COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` text COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(11) NOT NULL,
  `BirthDate` date NOT NULL,
  `JoinDate` date NOT NULL,
  `Gender` binary(1) NOT NULL,
  `Address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Department` text COLLATE utf8_unicode_ci NOT NULL,
  `Site` text COLLATE utf8_unicode_ci NOT NULL,
  `PatientIsActive` tinyint(1) NOT NULL DEFAULT '1',
  `PatientIsActive_ChangeDatetime` date NOT NULL,
  `TableChange_User` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TableChange_Datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Row_ID`),
  UNIQUE KEY `IdentityCard` (`PatientID`),
  KEY `Patient_ID` (`Row_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patients`
--

/*!40000 ALTER TABLE `Patients` DISABLE KEYS */;
INSERT INTO `Patients` VALUES (1,111610819,'Ramiro','Vargas','Quiros','rvq25@hotmail.com',25589845,'2017-01-03','2016-12-27','\0','Calle C','','Department1','Site1',1,'0000-00-00','','2016-12-16 21:11:13'),(2,111610820,'Ericka','Venegas','Gomez','even562@yahoo.com',89173632,'0000-00-00','0000-00-00','','','','','',1,'0000-00-00','','2016-12-16 21:45:06'),(3,111610715,'Jorge','Murillo','Hernandez','jmhernandez@yahoo.co',0,'0000-00-00','0000-00-00','\0','','','','',1,'0000-00-00','','2016-12-18 04:44:11'),(5,410161000,'Julieta','Tatatata','Angulo','juliet_auop@ac.co.cr',22268010,'0000-00-00','0000-00-00','\0','','','','',1,'0000-00-00','','2016-12-18 04:53:02'),(6,620022351,'Arturo','Ulloa','Santos','arthur@ac.cr',78901225,'0000-00-00','0000-00-00','\0','Cartago','','','Site1',1,'0000-00-00','','2016-12-18 04:59:24'),(8,111610419,'Juana','Vargas','Gomez','',0,'0000-00-00','0000-00-00','\0','','','','',1,'0000-00-00','','2016-12-28 06:10:30'),(9,111610403,'Hernan','Jimenez','Carreño','',0,'0000-00-00','0000-00-00','\0','','','','',1,'0000-00-00','','2016-12-28 06:11:41'),(12,65967000,'Julian','Arango','Hernandez','',0,'0000-00-00','0000-00-00','\0','','','','',1,'0000-00-00','','2016-12-28 06:14:14'),(13,101245013,'adrian','huerta','prado','adrian@ice.go.cr',777777,'0000-00-00','0000-00-00','\0','','Company1','','Site1',1,'0000-00-00','','2017-01-24 22:59:56'),(14,11223223,'mariano','chavez','rojas','a@d',0,'0000-00-00','0000-00-00','\0','','Company1','','',1,'0000-00-00','','2017-01-27 06:09:21'),(17,2147483647,'hernan','vargas','hernandez','e@h',0,'0000-00-00','0000-00-00','\0','','Company1','','',1,'0000-00-00','','2017-01-31 03:24:48');
/*!40000 ALTER TABLE `Patients` ENABLE KEYS */;

--
-- Table structure for table `PhysiologicalVars`
--

DROP TABLE IF EXISTS `PhysiologicalVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PhysiologicalVars` (
  `RowID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `VarType` text COLLATE utf8_unicode_ci NOT NULL,
  `Unit` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PhysiologicalVars`
--

/*!40000 ALTER TABLE `PhysiologicalVars` DISABLE KEYS */;
/*!40000 ALTER TABLE `PhysiologicalVars` ENABLE KEYS */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `Row_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Username` text COLLATE utf8_unicode_ci NOT NULL,
  `PassHash` text COLLATE utf8_unicode_ci NOT NULL,
  `Forename` text COLLATE utf8_unicode_ci NOT NULL,
  `FirstSurname` text COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` text COLLATE utf8_unicode_ci NOT NULL,
  `Email` text COLLATE utf8_unicode_ci NOT NULL,
  `Group` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Row_ID`),
  UNIQUE KEY `UserID` (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;

--
-- Dumping events for database 'u505969032_bicoy'
--

--
-- Dumping routines for database 'u505969032_bicoy'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-03 19:50:19
