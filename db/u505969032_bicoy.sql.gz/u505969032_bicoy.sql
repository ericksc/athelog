-- MySQL dump 10.16  Distrib 10.1.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.20-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `CompanyID` (`CompanyID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

/*!40000 ALTER TABLE `Companies` DISABLE KEYS */;
INSERT INTO `Companies` VALUES (1,'OdiseaSA',22240137,'odisea@odisea.co.cr','San Jose, 150001','active','2017-02-13 11:30:18',0,'','0'),(2,'SerranoSA',25546687,'info@serrano.co.cr','calle blancos','active','2017-02-13 11:30:18',0,'','0'),(3,'CarguilLTDA',66666666,'carguil@carguil.sa.c','Cartago, Mercado','active','2017-02-13 11:30:18',0,'','0'),(4,'CargoSHIP',22534504,'info@cargo.ship.cr','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18',0,'','0'),(5,'FireINC',11111111,'info@fire.ucs.cal','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18',0,'','0'),(7,'arenasa',1221455,'info@arena.net','call ddd ddf dfdfdf <z<zz','active','2017-03-13 01:26:07',0,'','false');
/*!40000 ALTER TABLE `Companies` ENABLE KEYS */;

--
-- Table structure for table `CompanyDepartments`
--

DROP TABLE IF EXISTS `CompanyDepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanyDepartments` (
  `RowID` bigint(20) NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DepartmentID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanyDepartments`
--

/*!40000 ALTER TABLE `CompanyDepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanyDepartments` ENABLE KEYS */;

--
-- Table structure for table `CompanySites`
--

DROP TABLE IF EXISTS `CompanySites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanySites` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SiteID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanySites`
--

/*!40000 ALTER TABLE `CompanySites` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanySites` ENABLE KEYS */;

--
-- Table structure for table `EvaluationConst`
--

DROP TABLE IF EXISTS `EvaluationConst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationConst` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `APP_Hypertension` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Diabetes` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Cardiomyopathy` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Obesity` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Dyslipidemia` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Sedentarism` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Depression` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Alcohol` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Tobacco` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `APNP_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `AQX_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `MED_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `INJ_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Quest_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Ind_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Ntrtn_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `PhysThrpy_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `RowID` (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationConst`
--

/*!40000 ALTER TABLE `EvaluationConst` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvaluationConst` ENABLE KEYS */;

--
-- Table structure for table `EvaluationHistory`
--

DROP TABLE IF EXISTS `EvaluationHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationHistory` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Test` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Value` float NOT NULL,
  `Unit` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationHistory`
--

/*!40000 ALTER TABLE `EvaluationHistory` DISABLE KEYS */;
INSERT INTO `EvaluationHistory` VALUES (1,111610819,'custom3',1,'','2017-03-10 00:40:36',555,'','false'),(2,111610819,'custom5',4,'','2017-03-10 00:40:47',55554543,'','false'),(3,111610819,'custom0',6,'','2017-03-10 00:40:27',0,'','false'),(4,111610819,'HeartFreq',1,'','2017-03-03 15:07:43',0,'','false'),(5,111610819,'BldPrssr',4,'','2017-03-03 15:07:43',0,'','false'),(6,111610819,'Glycemia',6,'','2017-03-03 15:07:43',0,'','false'),(7,111610819,'HeartFreq',1,'','2017-03-03 15:07:47',0,'','false'),(8,111610819,'BldPrssr',4,'','2017-03-03 15:07:47',0,'','false'),(9,111610819,'Glycemia',6,'','2017-03-03 15:07:47',0,'','false'),(10,111610819,'HeartFreq',1,'','2017-03-03 15:07:55',0,'','false'),(11,111610819,'BldPrssr',8,'','2017-03-03 15:07:55',0,'','false'),(12,111610819,'Glycemia',6,'','2017-03-03 15:07:55',0,'','false'),(13,111610819,'SO2',0.5,'','2017-03-03 15:17:50',0,'','false'),(14,111610819,'WaistCirc',2.5,'','2017-03-03 15:17:50',0,'','false'),(15,111610819,'V2OMax',1.5,'','2017-03-03 15:17:50',0,'','false'),(16,111610819,'BldPrssr',1.5,'','2017-03-03 15:19:53',0,'','false'),(17,111610819,'VO2Max',0,'','2017-03-03 15:19:53',0,'','false'),(18,111610819,'BldPrssr',1.5,'','2017-03-03 15:21:07',0,'','false'),(19,111610819,'VO2Max',0,'','2017-03-03 15:21:07',0,'','false'),(20,111610819,'VO2Max',1.8,'','2017-03-03 15:21:38',0,'','false'),(21,111610819,'test1',666,'','2017-03-03 15:44:59',0,'','false'),(22,111610819,'test4',56565,'','2017-03-04 04:04:48',555,'','false'),(23,21223552,'HeartFreq',2,'','2017-03-10 00:39:38',0,'','false'),(24,21223552,'BldPrssr',10,'','2017-03-10 00:39:38',0,'','false'),(25,21223552,'Glycemia',5,'','2017-03-10 00:39:38',0,'','false'),(26,21223552,'SO2',8,'','2017-03-10 00:39:38',0,'','false'),(27,21223552,'WaistCirc',9,'','2017-03-10 00:39:38',0,'','false'),(28,21223552,'VO2Max',10,'','2017-03-10 00:39:38',0,'','false'),(29,53001225,'HeartFreq',10,'','2017-03-10 00:54:37',0,'','false'),(30,53001225,'BldPrssr',15,'','2017-03-10 00:54:37',0,'','false'),(31,53001225,'Glycemia',35,'','2017-03-10 00:54:37',0,'','false'),(32,53001225,'SO2',82,'','2017-03-10 00:54:37',0,'','false'),(33,53001225,'WaistCirc',150,'','2017-03-10 00:54:37',0,'','false'),(34,53001225,'VO2Max',233,'','2017-03-10 00:54:37',0,'','false'),(35,53001225,'otro_test',1025,'','2017-03-10 00:54:37',0,'','false');
/*!40000 ALTER TABLE `EvaluationHistory` ENABLE KEYS */;

--
-- Table structure for table `Patients`
--

DROP TABLE IF EXISTS `Patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Patients` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` int(20) NOT NULL,
  `BirthDate` date NOT NULL,
  `JoinDate` date NOT NULL,
  `Gender` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'indefinido',
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Department` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Site` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `Income` int(10) NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `PatientID` (`PatientID`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patients`
--

/*!40000 ALTER TABLE `Patients` DISABLE KEYS */;
INSERT INTO `Patients` VALUES (18,111610819,'ramiro','JJ','Vargas','Quiros','rvq25@hotmail.com',25519848,'0000-00-00','0000-00-00','Masculino','Res Bellavista ','OdiseaSA','No indica','No indica','active',3500000,'2017-03-13 08:24:52',111115511,'','false'),(19,21223552,'juan',NULL,'perez','solano','j@h.com',2112212,'0000-00-00','0000-00-00','indefinido','SJ','SerranoSA','IT','','active',0,'2017-03-09 22:44:55',0,'','false'),(20,53001225,'fernando',NULL,'vargas','lopez','f@hotmail.com',123222,'0000-00-00','0000-00-00','indefinido','HER','SerranoSA','Ventas','','active',0,'2017-03-10 00:42:07',0,'','false'),(21,93302458,'armando','julio','zamorano','gomez','a@g',12121,'0000-00-00','0000-00-00','Masculino','Desampa','fireinc','','NONE','active',150000,'2017-03-13 08:24:26',0,'','false'),(22,40110921,'maria','ana','cardenas','ulloa','NONE',0,'0000-00-00','0000-00-00','Femenino','Turrucares','FireINC','','No indica','active',800000,'2017-03-13 09:30:11',0,'','false');
/*!40000 ALTER TABLE `Patients` ENABLE KEYS */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserID` bigint(20) NOT NULL,
  `PassHash` text COLLATE utf8_unicode_ci NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `UserGroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'inactive',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,111610819,'f226724bac26b888d6fa223c50c57ed0fbf85e93afd747e205116fc454ab872b','ramiro','na','vargas','quiros','ramirovq@gmail.com',0,'Developer','OdiseaSA','active','2017-03-13 08:55:58',0,'','false'),(2,111610820,'31073216d2300a8050cac7e11a2eef2f42b7eba6d1bb96309487df365083fe3a','erick','','salas','chaverri','',0,'administrator','carguilltda','active','2017-03-06 13:13:14',0,'','false'),(3,111610821,'758214000e1107b458adb63b8e780cc84014a8d742d80b7eb0b2da9fbddc811e','adrian','','guzman','solano','',0,'viewer','fireinc','active','2017-03-06 13:12:49',0,'','false'),(4,111610822,'d8163eef7023215d2fb2d357319be86df86ca4571c306eceb4eb3ba19cb7646e','jorge','','kuhl','kokan','',0,'guest','odiseasa','active','2017-03-06 13:12:39',0,'','false'),(5,20012533,'','luisa','','gutierrez','hernandez','',0,'viewer','serranosa','active','2017-02-28 00:03:22',0,'','false'),(6,92102003,'','luana','','sanchez','chavarria','luana@sc.ht.com',0,'guest','serranosa','active','2017-02-28 00:03:27',0,'','false'),(8,411203889,'1511','mario','julieto','ordonez','challet','ramirovq@gmail.com',89173644,'Developer','OdiseaSA','active','2017-03-13 09:27:21',0,'','false'),(9,4936524176,'1511','julian','gonzalo','hernandez','salas','undefined',0,'editor','FireINC','inactive','2017-02-28 00:08:19',0,'','false'),(14,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:26',0,'','false'),(15,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:33',0,'','false'),(16,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:29',0,'','false'),(13,511202213,'444','alfonso','allan','jimenez','angulo','undefined',0,'viewer','SerranoSA','inactive','2017-02-24 23:26:05',0,'','false'),(17,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:37',0,'','false'),(18,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:41',0,'','false'),(19,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'administrator','NONE','inactive','2017-03-06 12:25:44',0,'','false'),(20,111610825,'NONE','javier','NONE','gonzalez','murillo','undefined',0,'Guest','FireINC','inactive','2017-03-07 03:00:53',0,'','false'),(21,111610825,'NONE','javier','NONE','gonzalez','murillo','undefined',0,'Guest','FireINC','inactive','2017-03-07 03:00:54',0,'','false'),(22,99881225,'NONE','mariano','NONE','velez','cardona','undefined',0,'Viewer','FireINC','active','2017-03-13 00:28:03',0,'','false');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;

--
-- Dumping events for database 'u505969032_bicoy'
--

--
-- Dumping routines for database 'u505969032_bicoy'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-14 22:14:53
