-- MySQL dump 10.16  Distrib 10.1.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.20-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `CompanyID` (`CompanyID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

/*!40000 ALTER TABLE `Companies` DISABLE KEYS */;
INSERT INTO `Companies` VALUES (1,'OdiseaSA',99999999,'odisea@odisea.co.cr','San Jose, 150001','active','2017-02-13 11:30:18',0,'','0'),(2,'SerranoSA',555555555,'serrano@serrano.co.c','Heredia, Cariari','active','2017-02-13 11:30:18',0,'','0'),(3,'CarguilLTDA',66666666,'carguil@carguil.sa.c','Cartago, Mercado','active','2017-02-13 11:30:18',0,'','0'),(4,'CargoSHIP',22534504,'info@cargo.ship.cr','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18',0,'','0'),(5,'FireINC',11111111,'info@fire.ucs.cal','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18',0,'','0');
/*!40000 ALTER TABLE `Companies` ENABLE KEYS */;

--
-- Table structure for table `CompanyDepartments`
--

DROP TABLE IF EXISTS `CompanyDepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanyDepartments` (
  `RowID` bigint(20) NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DepartmentID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanyDepartments`
--

/*!40000 ALTER TABLE `CompanyDepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanyDepartments` ENABLE KEYS */;

--
-- Table structure for table `CompanySites`
--

DROP TABLE IF EXISTS `CompanySites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanySites` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SiteID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanySites`
--

/*!40000 ALTER TABLE `CompanySites` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanySites` ENABLE KEYS */;

--
-- Table structure for table `EvaluationConst`
--

DROP TABLE IF EXISTS `EvaluationConst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationConst` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `APP_Hypertension` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Diabetes` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Cardiomyopathy` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Obesity` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Dyslipidemia` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Sedentarism` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Depression` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Alcohol` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Tobacco` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `APP_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `APNP_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `AQX_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `MED_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `INJ_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Quest_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Ind_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `Ntrtn_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `PhysThrpy_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `RowID` (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationConst`
--

/*!40000 ALTER TABLE `EvaluationConst` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvaluationConst` ENABLE KEYS */;

--
-- Table structure for table `EvaluationHistory`
--

DROP TABLE IF EXISTS `EvaluationHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationHistory` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Test` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Value` float NOT NULL,
  `Unit` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationHistory`
--

/*!40000 ALTER TABLE `EvaluationHistory` DISABLE KEYS */;
INSERT INTO `EvaluationHistory` VALUES (1,111610819,'0',1,'','2017-03-04 04:04:51',555,'','false'),(2,111610819,'0',4,'','2017-03-04 04:04:54',55554543,'','false'),(3,111610819,'0',6,'','2017-03-03 15:05:15',0,'','false'),(4,111610819,'HeartFreq',1,'','2017-03-03 15:07:43',0,'','false'),(5,111610819,'BldPrssr',4,'','2017-03-03 15:07:43',0,'','false'),(6,111610819,'Glycemia',6,'','2017-03-03 15:07:43',0,'','false'),(7,111610819,'HeartFreq',1,'','2017-03-03 15:07:47',0,'','false'),(8,111610819,'BldPrssr',4,'','2017-03-03 15:07:47',0,'','false'),(9,111610819,'Glycemia',6,'','2017-03-03 15:07:47',0,'','false'),(10,111610819,'HeartFreq',1,'','2017-03-03 15:07:55',0,'','false'),(11,111610819,'BldPrssr',8,'','2017-03-03 15:07:55',0,'','false'),(12,111610819,'Glycemia',6,'','2017-03-03 15:07:55',0,'','false'),(13,111610819,'SO2',0.5,'','2017-03-03 15:17:50',0,'','false'),(14,111610819,'WaistCirc',2.5,'','2017-03-03 15:17:50',0,'','false'),(15,111610819,'V2OMax',1.5,'','2017-03-03 15:17:50',0,'','false'),(16,111610819,'BldPrssr',1.5,'','2017-03-03 15:19:53',0,'','false'),(17,111610819,'VO2Max',0,'','2017-03-03 15:19:53',0,'','false'),(18,111610819,'BldPrssr',1.5,'','2017-03-03 15:21:07',0,'','false'),(19,111610819,'VO2Max',0,'','2017-03-03 15:21:07',0,'','false'),(20,111610819,'VO2Max',1.8,'','2017-03-03 15:21:38',0,'','false'),(21,111610819,'test1',666,'','2017-03-03 15:44:59',0,'','false'),(22,111610819,'test4',56565,'','2017-03-04 04:04:48',555,'','false');
/*!40000 ALTER TABLE `EvaluationHistory` ENABLE KEYS */;

--
-- Table structure for table `Patients`
--

DROP TABLE IF EXISTS `Patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Patients` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` int(20) NOT NULL,
  `BirthDate` date NOT NULL,
  `JoinDate` date NOT NULL,
  `Gender` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'indefinido',
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Department` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Site` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `Income` int(10) NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `PatientID` (`PatientID`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patients`
--

/*!40000 ALTER TABLE `Patients` DISABLE KEYS */;
INSERT INTO `Patients` VALUES (18,111610819,'ramiro','JJ','Vargas','Quiros','dummy@g.com',89173644,'0000-00-00','0000-00-00','indefinido','Cartago','noindica','Main','CRT','active',0,'2017-03-04 05:27:01',111115511,'','false');
/*!40000 ALTER TABLE `Patients` ENABLE KEYS */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserID` bigint(20) NOT NULL,
  `PassHash` text COLLATE utf8_unicode_ci NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `UserGroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'inactive',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  `LastIP` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FFD` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'false',
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,111610819,'','ramiro','na','vargas','quiros','ramirovq@gmail.com',25519848,'Editor','OdiseaSA','active','2017-02-25 03:28:38',0,'','false'),(2,12225233,'','erick','','salas','chaverri','',0,'administrator','carguilltda','active','2017-02-28 00:02:55',0,'','false'),(3,355512222,'','adrian','','guzman','solano','',0,'developer','fireinc','active','2017-02-28 00:03:01',0,'','false'),(4,882222222,'','jorge','','kuhl','kokan','',0,'editor','odiseasa','active','2017-02-28 00:03:09',0,'','false'),(5,20012533,'','luisa','','gutierrez','hernandez','',0,'viewer','serranosa','active','2017-02-28 00:03:22',0,'','false'),(6,92102003,'','luana','','sanchez','chavarria','luana@sc.ht.com',0,'guest','serranosa','active','2017-02-28 00:03:27',0,'','false'),(8,411203889,'1511','ramiro','julieto','vargas','challet','fdsfds',12121555,'viewer','CargoSHIP','inactive','2017-02-28 00:08:14',0,'','false'),(9,4936524176,'1511','julian','gonzalo','hernandez','salas','undefined',0,'editor','FireINC','inactive','2017-02-28 00:08:19',0,'','false'),(14,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:41:19',0,'','false'),(15,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:42:26',0,'','false'),(16,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:42:27',0,'','false'),(13,511202213,'444','alfonso','allan','jimenez','angulo','undefined',0,'viewer','SerranoSA','inactive','2017-02-24 23:26:05',0,'','false'),(17,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:42:34',0,'','false'),(18,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:42:34',0,'','false'),(19,8211524631,'NONE','esteban','allan','alfaro','salas','undefined',0,'Administrator','NONE','inactive','2017-02-28 00:42:34',0,'','false');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;

--
-- Dumping events for database 'u505969032_bicoy'
--

--
-- Dumping routines for database 'u505969032_bicoy'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-04 17:47:21
