-- MySQL dump 10.15  Distrib 10.0.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.0.28-MariaDB-wsrep

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Companies`
--

DROP TABLE IF EXISTS `Companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Companies` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifierID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `CompanyID` (`CompanyID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Companies`
--

/*!40000 ALTER TABLE `Companies` DISABLE KEYS */;
INSERT INTO `Companies` VALUES (1,'OdiseaSA',99999999,'odisea@odisea.co.cr','San Jose, 150001','active','2017-02-13 11:30:18',''),(2,'SerranoSA',555555555,'serrano@serrano.co.c','Heredia, Cariari','active','2017-02-13 11:30:18',''),(3,'CarguilLTDA',66666666,'carguil@carguil.sa.c','Cartago, Mercado','active','2017-02-13 11:30:18',''),(4,'CargoSHIP',22534504,'info@cargo.ship.cr','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18',''),(5,'FireINC',11111111,'info@fire.ucs.cal','Parque Industrial C. Blancos ','active','2017-02-13 11:30:18','');
/*!40000 ALTER TABLE `Companies` ENABLE KEYS */;

--
-- Table structure for table `CompanyDepartments`
--

DROP TABLE IF EXISTS `CompanyDepartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanyDepartments` (
  `RowID` bigint(20) NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DepartmentID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanyDepartments`
--

/*!40000 ALTER TABLE `CompanyDepartments` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanyDepartments` ENABLE KEYS */;

--
-- Table structure for table `CompanySites`
--

DROP TABLE IF EXISTS `CompanySites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CompanySites` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SiteID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CompanySites`
--

/*!40000 ALTER TABLE `CompanySites` DISABLE KEYS */;
/*!40000 ALTER TABLE `CompanySites` ENABLE KEYS */;

--
-- Table structure for table `EvaluationConst`
--

DROP TABLE IF EXISTS `EvaluationConst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationConst` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Test` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Value` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `RowID` (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationConst`
--

/*!40000 ALTER TABLE `EvaluationConst` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvaluationConst` ENABLE KEYS */;

--
-- Table structure for table `EvaluationHistory`
--

DROP TABLE IF EXISTS `EvaluationHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EvaluationHistory` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `PV_HghBldPrssr` float NOT NULL,
  `PV_Glycemia` float NOT NULL,
  `PV_SO2` float NOT NULL,
  `PV_WaistCirc` float NOT NULL,
  `PV_V2OMax` float NOT NULL,
  `PV_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `BodyComp_Weight` float NOT NULL,
  `BodyComp_GoalWeight` float NOT NULL,
  `BodyComp_FatMass` float NOT NULL,
  `BodyComp_MuscleMass` float NOT NULL,
  `BodyComp_BMI` float NOT NULL,
  `BodyComp_FatPer` float NOT NULL,
  `BodyComp_InBodyScore` float NOT NULL,
  `BodyComp_BasMet` float NOT NULL,
  `BodyComp_ViscFat` float NOT NULL,
  `BodyComp_Flex` float NOT NULL,
  `BodyComp_MR` float NOT NULL,
  `BodyComp_HydrtnLvl` float NOT NULL,
  `BodyComp_FatCntrl` float NOT NULL,
  `BodyComp_MuscleCntrl` float NOT NULL,
  `BodyComp_Cmmnt` text COLLATE utf8_unicode_ci NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `RowID` (`RowID`),
  UNIQUE KEY `RowID_2` (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EvaluationHistory`
--

/*!40000 ALTER TABLE `EvaluationHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `EvaluationHistory` ENABLE KEYS */;

--
-- Table structure for table `Patients`
--

DROP TABLE IF EXISTS `Patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Patients` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PatientID` bigint(20) NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Phone` int(20) NOT NULL,
  `BirthDate` date NOT NULL,
  `JoinDate` date NOT NULL,
  `Gender` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'indefinido',
  `Address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Department` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Site` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  `Income` int(10) NOT NULL,
  `ModDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `PatientID` (`PatientID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patients`
--

/*!40000 ALTER TABLE `Patients` DISABLE KEYS */;
INSERT INTO `Patients` VALUES (18,111550650,'Erick','Edgardo','Salas','Chaverri','ericksc@gmail.com',83115612,'1982-11-15','2001-11-15','indefinido','','','','','active',0,'2017-02-22 19:21:33',0),(19,99999999,'',NULL,'',NULL,NULL,0,'0000-00-00','0000-00-00','indefinido','','','','','active',0,'2017-02-22 19:48:01',0);
/*!40000 ALTER TABLE `Patients` ENABLE KEYS */;

--
-- Table structure for table `PhysiologicalVars`
--

DROP TABLE IF EXISTS `PhysiologicalVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PhysiologicalVars` (
  `RowID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `VarType` text COLLATE utf8_unicode_ci NOT NULL,
  `Unit` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`RowID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PhysiologicalVars`
--

/*!40000 ALTER TABLE `PhysiologicalVars` DISABLE KEYS */;
/*!40000 ALTER TABLE `PhysiologicalVars` ENABLE KEYS */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `RowID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserID` bigint(20) NOT NULL,
  `PassHash` text COLLATE utf8_unicode_ci NOT NULL,
  `Forename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MiddleName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FirstSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SecondSurname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` int(20) NOT NULL,
  `UserGroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CompanyID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'inactive',
  `LastMod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ModifierID` bigint(20) NOT NULL,
  PRIMARY KEY (`RowID`),
  UNIQUE KEY `UserID` (`UserID`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,111610819,'4ad78895185e25f304400cea7fa11a0483828310f786852d6dcbd61c68d0d1da','ramiro','','vargas','quiros','',89173644,'developer','athelog','active','2017-02-28 04:37:29',0),(2,30001583,'3f1f3d2ae8390f8006c43b8284aac19e96808884349d9860183926ab4dedb998','erick','','salas','chaverri','',0,'administrator','athelog','active','2017-02-28 04:38:04',0),(3,40125886,'','adrian','','guzman','solano','',0,'developer','bicoyed','active','2017-02-19 20:03:19',0),(4,70131558,'','jorge','','kuhl','kokan','',0,'editor','bicoyed','active','2017-02-19 20:03:19',0),(5,632152223,'','luisa','','gutierrez','hernandez','',0,'viewer','sacsasa','active','2017-02-19 20:03:19',0),(6,50001585,'','luana','','sanchez','chavarria','luana@sc.ht.com',0,'guest','sacsa','active','2017-02-19 20:03:19',0),(7,0,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:00:25',0),(8,99999,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:02:57',0),(9,12345,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:17:15',0),(10,123456,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:48:34',0),(11,1234567,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:50:02',0),(12,12345678,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:50:45',0),(13,123456789,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:52:10',0),(14,12345678910,'','',NULL,'','','',0,'','','inactive','2017-02-25 01:53:05',0),(15,1234567891011,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:05:44',0),(16,123456789101112,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:06:55',0),(17,12345678910111213,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:08:24',0),(18,1234567891011121314,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:09:18',0),(19,9223372036854775807,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:11:20',0),(20,987654,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:24:54',0),(21,9876543,'','',NULL,'','','',0,'','','inactive','2017-02-25 02:27:13',0);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-02 15:12:49
